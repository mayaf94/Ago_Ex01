#ifndef EDGE_H
#define EDGE_H

typedef struct Edge {

	int start;
	int dest;
	int capacity;
};

#endif